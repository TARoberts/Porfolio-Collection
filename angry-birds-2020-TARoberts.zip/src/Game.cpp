
#include "Game.h"
#include "GameObject.h"
#include "Vector2.h"
#include <iostream>

Game::Game(sf::RenderWindow& game_window)
  : window(game_window)
{
  srand(time(NULL));
}

Game::~Game()
{

}

bool Game::init()
{
  speed = 5.0f;
  gravity = 1.f;
  drag = 0.4f;
  score = 0;
  lives = 5;
  mouseDown = false;
  velocityX = 0.0f;
  velocityY = 0.0f;
  activeBird = 0;

  if(!font.loadFromFile("Data/Fonts/OpenSans-Bold.ttf"))
  {
    std::cout<<"font did not load\n";
  }

  if (!initMenuText())
  {
    return false;
  }

  if (!initControlsText())
  {
    return false;
  }

  if (!initGameText())
  {
    return false;
  }

  if (!initWinnerText())
  {
    return false;
  }

  if (!initLoserText())
  {
    return false;
  }

  if (!initBackground())
  {
    return false;
  }

  if (!initBirdsAndSling())
  {
    return false;
  }

  if (!initBricks())
  {
    return false;
  }

  return true;
}

bool Game::initBricks()
{
  int brickX = window.getSize().x/48;
  int slingY = window.getSize().y - 200;

  for (int i = 0; i < 5; i++)
  {
    bricks[i] = new GameObject(
      "Data/Images/kenney_physicspack/PNG/Metal elements/elementMetal017.png",
      brickX*((i*4)+27),slingY);

    bricks[i]->getSprite()->setScale(0.5, 0.5);
  }

  return true;
}

bool Game::initBirdsAndSling()
{
  int slingX = window.getSize().x / 8;
  int slingY = window.getSize().y - 200;

  sling = new GameObject(
    "Data/Images/kenney_physicspack/PNG/Other/cactus.png", slingX, slingY);
  sling->getSprite()->setScale(1.5,1.5);

  int twelveX = window.getSize().x / 12;

  for (int i = 0; i < 5; i++)
  {
    pigs[i] = new GameObject(
      "Data/Images/kenney_animalpackredux/PNG/Round (outline)/pig.png",
      (twelveX*(i+7)), slingY);
    pigs[i]->getSprite()->setScale(0.5, 0.5);
  }

  birds[0] = new BirdObject(
    "Data/Images/kenney_animalpackredux/PNG/Round (outline)/owl.png",
    slingX,
    slingY);
  birds[0]->getSprite()->setScale(0.5, 0.5);
  birds[0]->getSprite()->setOrigin(birds[0]->getSprite()->getGlobalBounds().width,
                                   birds[0]->getSprite()->getGlobalBounds().height);

  for (int i = 1; i < 5; i++)
  {
    birds[i] = new BirdObject(
      "Data/Images/kenney_animalpackredux/PNG/Round (outline)/owl.png",
      slingX,
      slingY);
    birds[i]->getSprite()->setScale(0.5, 0.5);

    float birdHeight = birds[i]->getSprite()->getGlobalBounds().height;
    float birdWidth  = birds[i]->getSprite()->getGlobalBounds().width;

    birds[i]->getSprite()->setPosition(slingX - (birdWidth * i) + birdWidth*2,
                                       (slingY + birdHeight* 2));

    birds[i]->getSprite()->setOrigin(birdWidth, birdHeight);
  }


  activeBirdPos = {birds[0]->getSprite()->getPosition().x,
                   birds[0]->getSprite()->getPosition().y};

  return true;
}

bool Game::initMenuText()
{
  title_text.setString("Welcome to Angry Birds!");
  title_text.setFont(font);
  title_text.setCharacterSize(40);
  title_text.setFillColor(sf::Color(255,255,255,255));
  title_text.setPosition(
    window.getSize().x / 2 - title_text.getGlobalBounds().width / 2,
    window.getSize().y / 2 - title_text.getGlobalBounds().height / 2);

  menu_text.setString("Press Spacebar to continue!");
  menu_text.setFont(font);
  menu_text.setCharacterSize(30);
  menu_text.setFillColor(sf::Color(255,255,255,255));
  menu_text.setPosition(
    window.getSize().x / 2 - menu_text.getGlobalBounds().width / 2,
    window.getSize().y / 2 + menu_text.getGlobalBounds().height*2);

  return true;
}

bool Game::initControlsText()
{
  controls_text.setString("Click and drag the Bird backwards to slingshot!"
                          "\nPress Escape to quit at any time!");
  controls_text.setFont(font);
  controls_text.setCharacterSize(40);
  controls_text.setFillColor(sf::Color(255,255,255,255));
  controls_text.setPosition(
    window.getSize().x / 2 - controls_text.getGlobalBounds().width / 2,
    window.getSize().y / 2 - controls_text.getGlobalBounds().height / 2);

  return true;
}

bool Game::initGameText()
{
  score_text.setString("Your score is: " + std::to_string(score));
  score_text.setFont(font);
  score_text.setCharacterSize(20);
  score_text.setFillColor(sf::Color(255,255,255,255));
  score_text.setPosition(
    window.getSize().x / 10,
    window.getSize().y  - score_text.getGlobalBounds().height * 2);

  return true;
}

bool Game::initWinnerText()
{
  winner_text.setString("You win!");
  winner_text.setFont(font);
  winner_text.setCharacterSize(70);
  winner_text.setFillColor(sf::Color(255,255,255,255));
  winner_text.setPosition(
    window.getSize().x / 2 - winner_text.getGlobalBounds().width / 2,
    window.getSize().y / 2 - winner_text.getGlobalBounds().height / 2);

  replay_text.setString("Press Spacebar to go back to the main menu.");
  replay_text.setFont(font);
  replay_text.setCharacterSize(50);
  replay_text.setFillColor(sf::Color(255,255,255,255));
  replay_text.setPosition(
    window.getSize().x / 2 - replay_text.getGlobalBounds().width / 2,
    window.getSize().y / 1.5 - replay_text.getGlobalBounds().height / 2);

  return true;
}

bool Game::initLoserText()
{
  loser_text.setString("You lose!");
  loser_text.setFont(font);
  loser_text.setCharacterSize(70);
  loser_text.setFillColor(sf::Color(255,255,255,255));
  loser_text.setPosition(
    window.getSize().x / 2 - loser_text.getGlobalBounds().width / 2,
    window.getSize().y / 2 - loser_text.getGlobalBounds().height / 2);

  return true;
}

bool Game::initBackground()
{
  if (!background_texture.loadFromFile("Data/Images/lvl1_test.png"))
  {
    std::cout << "Error loading texture";
  }
  background.setTexture(background_texture);
  background.setPosition(0,0);
  background.setScale(1,1);

  return true;
}

bool Game::calcBoundsX()
{
  float x = static_cast<float>(sf::Mouse::getPosition(window).x)
    - sling->getSprite()->getPosition().x - 50;
  if (x >= 0)
  {
    return true;
  }
  else
  {
    return false;
  }
}

bool Game::calcBoundsY()
{
  float y = static_cast<float>(sf::Mouse::getPosition(window).y)
            - sling->getSprite()->getPosition().y + 50;
  if (y <= 0)
  {
    return true;
  }
  else
  {
    return false;
  }
}

void Game::moveBird(float dt)
{
  if ((birds[activeBird]->getSprite()->getPosition().y
         + birds[activeBird]->getSprite()->getGlobalBounds().height/2
      > sling->getSprite()->getPosition().y +
           sling->getSprite()->getGlobalBounds().height) &&
    (birds[activeBird]->getSprite()->getPosition().x >
       sling->getSprite()->getPosition().x))
  {
    velocityY = 0;
    velocityX = velocityX - (drag*4);
  }
  else
  {
    velocityX = velocityX - drag;
    velocityY = velocityY - gravity;
  }
  if (velocityX < 0)
  {
    velocityX = 0;
  }
  birds[activeBird]->getSprite()->move(birds[activeBird]->Movement.x * velocityX * dt * speed,
                           birds[activeBird]->Movement.y * velocityY * dt * -1 * speed);

  if (velocityX == 0 && velocityY == 0)
  {
    birds[activeBird]->Visible = false;
    activeBird +=1;
    lives -=1;
    birdHeld = true;
    if (activeBird < 5)
    {
      int slingX = window.getSize().x / 8;
      int slingY = window.getSize().y - 200;

      birds[activeBird]->getSprite()->setPosition(slingX, slingY);
    }

  }

}

void Game::pigCollision()
{
  for (int i = 0; i < 5; i++)
  {
    if (birds[activeBird]->getSprite()->getGlobalBounds().intersects(
          pigs[i]->getSprite()->getGlobalBounds()) && (pigs[i]->Visible))
    {
      pigs[i]->Visible = false;
      score += 1000;
      velocityY -= 5;
      velocityX -= 10;
    }
  }
}

void Game::brickCollision()
{
  for (int i = 0; i < 5; i++)
  {
    if (birds[activeBird]->getSprite()->getGlobalBounds().intersects(
      bricks[i]->getSprite()->getGlobalBounds()) && (bricks[i]->Visible))
    {
      bricks[i]->Visible = false;
      score += 500;
      velocityY -= 10;
      velocityX -= 20;
    }
  }
}

void Game::resetGame()
{
  activeBird = 0;
  lives = 5;
  velocityX = 0.0f;
  velocityY = 0.0f;
  score = 0;
  score_text.setString("Your score is: " + std::to_string(score));
  birdHeld = true;


  for (int i = 0; i < 5; i++)
  {
    birds[i]->Visible = true;
    pigs[i]->Visible = true;
    bricks[i]->Visible = true;
  }

  float slingX = sling->getSprite()->getPosition().x;
  float slingY = sling->getSprite()->getPosition().y;

  birds[0]->getSprite()->setPosition(slingX, slingY);

  for (int i = 1; i < 5; i++)
  {
    float birdHeight = birds[i]->getSprite()->getGlobalBounds().height;
    float birdWidth  = birds[i]->getSprite()->getGlobalBounds().width;

    birds[i]->getSprite()->setPosition(
      slingX - (birdWidth * i) + birdWidth * 2, (slingY + birdHeight * 2));

    birds[i]->getSprite()->setOrigin(birdWidth, birdHeight);

    currentState = menuScreen;
  }
}

void Game::update(float dt)
{
  if (currentState == gameScreen)
  {
    pigCollision();

    brickCollision();

    bool boundX = calcBoundsX();
    bool boundY = calcBoundsY();
    if(mouseDown && !boundX && !boundY && birdHeld)
    {
      activeBirdPos = {static_cast<float>(sf::Mouse::getPosition(window).x),
                       static_cast<float>(sf::Mouse::getPosition(window).y)};

      birds[activeBird]->getSprite()->setPosition(activeBirdPos.x,activeBirdPos.y);
    }

    if (!birdHeld && !mouseDown)
    {
      moveBird(dt);
    }



    score_text.setString("Your score is: " + std::to_string(score));
  }


  if (currentState == gameScreen)
  {
    bool gameWin = true;

    for (int i = 0; i <5; i++)
    {
      if (pigs[i]->Visible)
      {
        gameWin = false;
      }
    }

    if (gameWin)
    {
      currentState = winScreen;
    }
    else if (activeBird == 5)
    {
      for (int i = 0; i < 5; i++)
      {
        birds[i]->Visible = false;
        pigs[i]->Visible = false;
        bricks[i]->Visible = false;
      }
      currentState = loseScreen;
    }

  }

}

void Game::render()
{
  window.draw(background);

  switch (currentState)
  {
    case menuScreen:

      renderMenuText();

      break;

    case controlScreen:

      renderControlsText();

      break;

    case gameScreen:

      renderGameText();
      window.draw(*sling->getSprite());

      for (int i = 0; i < 5; i++)
      {
        if (birds[i]->Visible)
        {
          window.draw(*birds[i]->getSprite());
        }
      }

      for (int i = 0; i < 5; i ++)
      {
        if (pigs[i]->Visible)
        {
          window.draw((*pigs[i]->getSprite()));
        }
      }

      renderBricks();

      break;

    case winScreen:

      renderWinnerText();

      break;

    case loseScreen:

      renderLoserText();

      break;
  }

}

void Game::renderMenuText()
{
  window.draw(title_text);
  window.draw(menu_text);
}

void Game::renderControlsText()
{
  window.draw(menu_text);
  window.draw(controls_text);
}

void Game::renderGameText()
{
  window.draw(score_text);
}

void Game::renderWinnerText()
{
  window.draw(winner_text);
  window.draw(score_text);
  window.draw(replay_text);
}

void Game::renderLoserText()
{
  window.draw(loser_text);
  window.draw(score_text);
  window.draw(replay_text);
}

void Game::renderBricks()
{
  for (int i = 0; i <5; i++)
  {
    if (bricks[i]->Visible)
    {
      window.draw((*bricks[i]->getSprite()));
    }
  }

}

void Game::mouseClicked(sf::Event event)
{
  if (currentState == gameScreen)
  {
    if (birdHeld)
    {
      mouseDown = true;
    }
  }
}

void Game::mouseReleased(sf::Event event)
{
  if (currentState == gameScreen && birdHeld)
  {
    mouseDown = false;
    birdHeld = false;

    velocityX = static_cast<float>(sf::Mouse::getPosition(window).x)
                - sling->getSprite()->getPosition().x;
    if (velocityX < 0)
    {
      velocityX = velocityX*-1;
    }

    velocityY = static_cast<float>(sf::Mouse::getPosition(window).y)
                - sling->getSprite()->getPosition().y;

    if (velocityY < 0)
    {
      velocityY = velocityY * -1;
    }


  }

}

void Game::keyPressed(sf::Event event)
{
  if (event.key.code == sf::Keyboard::Space)
  {
    if (currentState == menuScreen)
    {
      currentState = controlScreen;
    }
    else if (currentState == controlScreen)
    {
      currentState = gameScreen;
    }

    else if (currentState == loseScreen || currentState == winScreen)
    {
      resetGame();
    }
  }

  if (event.key.code == sf::Keyboard::Escape)
  {
    window.close();
  }

}


