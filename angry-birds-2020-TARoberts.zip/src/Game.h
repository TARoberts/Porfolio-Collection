
#ifndef ANGRYBIRDS_GAME_H
#define ANGRYBIRDS_GAME_H

#include "GameObject.h"
#include "Vector2.h"
#include <SFML/Graphics.hpp>
#include "BirdObject.h"

class Game
{
 public:
  Game(sf::RenderWindow& window);
  ~Game();
  bool init();
  bool initMenuText();
  bool initGameText();
  bool initLoserText();
  bool initWinnerText();
  bool initControlsText();
  bool initBackground();
  void update(float dt);
  void render();
  void renderMenuText();
  void renderGameText();
  void renderLoserText();
  void renderWinnerText();
  void renderControlsText();
  void mouseClicked(sf::Event event);
  void keyPressed(sf::Event event);
  void mouseReleased(sf::Event event);
  bool calcBoundsX();
  bool calcBoundsY();
  void moveBird(float dt);
  void pigCollision();
  void resetGame();
  void brickCollision();
  bool initBirdsAndSling();
  bool initBricks();
  void renderBricks();

 private:
  sf::RenderWindow& window;
  sf::Font font;
  sf::Text title_text;
  sf::Text menu_text;
  sf::Text controls_text;
  sf::Text winner_text;
  sf::Text replay_text;
  sf::Text loser_text;
  sf::Text score_text;
  sf::Sprite background;
  sf::Texture background_texture;
  float speed;
  float gravity;
  float drag;
  float velocityX;
  float velocityY;
  int score;
  int lives;
  int activeBird;
  Vector2 activeBirdPos = {0.0f, 0.0f};
  bool mouseDown = false;
  bool birdHeld = true;

  enum gameState
  {
    menuScreen,
    controlScreen,
    gameScreen,
    winScreen,
    loseScreen,
  };

  gameState currentState = menuScreen;

  GameObject* sling;
  GameObject* pigs[5];
  GameObject* bricks[5];
  BirdObject* birds[5];


};

#endif // ANGRYBIRDS_GAME_H
