//
// Created by tom_A on 26/03/2021.
//
#include <SFML/Graphics.hpp>
#include "iostream"
#include "GameObject.h"

GameObject::GameObject(std::string filename, int x, int y) {

  if (!Object_Texture.loadFromFile(filename))
  {
    std::cout<<"Object did not load correctly.\n";
  }

  GObject.setTexture(Object_Texture);
  GObject.setPosition(x, y);
  GObject.setScale(1,1);
  Visible = true;

}

GameObject::~GameObject()
{

}

sf::Sprite* GameObject::getSprite()
{
  return &GObject;
}
