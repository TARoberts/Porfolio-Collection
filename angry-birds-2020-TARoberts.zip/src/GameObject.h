//
// Created by tom_A on 26/03/2021.
//

#ifndef ANGRYBIRDSSFML_GAMEOBJECT_H
#define ANGRYBIRDSSFML_GAMEOBJECT_H
#include <SFML/Graphics.hpp>
#include "Vector2.h"

class GameObject
{
 public:
  GameObject(std::string filename, int x, int y);
  ~GameObject();

  sf::Sprite* getSprite();
  bool Visible;
  std::string filename;

 private:

  sf::Sprite GObject;
  sf::Texture Object_Texture;
  sf::Sprite* sprite = nullptr;

};

#endif // ANGRYBIRDSSFML_GAMEOBJECT_H
