//
// Created by tom_A on 02/04/2021.
//

#ifndef ANGRYBIRDSSFML_BIRDOBJECT_H
#define ANGRYBIRDSSFML_BIRDOBJECT_H
#include "Vector2.h"
#include <SFML/Graphics.hpp>
#include "iostream"

class BirdObject
{
 public:
  BirdObject(std::string filename, int x, int y);
  ~BirdObject();

  sf::Sprite* getSprite();
  bool Visible;
  std::string filename;
  Vector2 Movement = {1.0,1.0};

 private:

  sf::Sprite GObject;
  sf::Texture Object_Texture;
  sf::Sprite* sprite = nullptr;

};

#endif // ANGRYBIRDSSFML_BIRDOBJECT_H
