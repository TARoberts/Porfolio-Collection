//
// Created by tom_A on 02/04/2021.
//

#include "BirdObject.h"
#include <SFML/Graphics.hpp>
#include "iostream"
#include "Vector2.h"


BirdObject::BirdObject(std::string filename, int x, int y) {

  if (!Object_Texture.loadFromFile(filename))
  {
    std::cout<<"Object did not load correctly.\n";
  }

  GObject.setTexture(Object_Texture);
  GObject.setPosition(x, y);
  GObject.setScale(1,1);
  Visible = true;
  Movement = {1.0,1.0};

}

BirdObject::~BirdObject()
{

}

sf::Sprite* BirdObject::getSprite()
{
  return &GObject;
}

